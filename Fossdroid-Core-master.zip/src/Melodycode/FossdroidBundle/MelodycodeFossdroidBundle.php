<?php

namespace Melodycode\FossdroidBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class MelodycodeFossdroidBundle extends Bundle
{
}
